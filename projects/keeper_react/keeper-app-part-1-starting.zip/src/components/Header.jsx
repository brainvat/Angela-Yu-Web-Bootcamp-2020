import React from "react";

const Header = function() {
  return (
    <header>
      <h1>Keeper</h1>
    </header>
  );
};

export default Header;
